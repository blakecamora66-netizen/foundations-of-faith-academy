const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: { rejectUnauthorized: false }, max: 5 });
const origin = process.env.FRONTEND_ORIGIN || '*';

function send(res, status, body) { res.status(status).json(body); }
function tokenFrom(req) { const h=req.headers.authorization||''; return h.startsWith('Bearer ')?h.slice(7):null; }
function userFrom(req) { const t=tokenFrom(req); if(!t) return null; try{return jwt.verify(t,process.env.JWT_SECRET)}catch{return null;} }
function requireUser(req,res){const u=userFrom(req); if(!u) send(res,401,{error:'Authentication required.'}); return u;}

module.exports = async (req,res)=>{
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Headers','Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  if(req.method==='OPTIONS') return res.status(204).end();
  const path=req.url.split('?')[0].replace(/\/+$/,'');
  try {
    if(req.method==='GET' && path.endsWith('/health')) return send(res,200,{ok:true,service:'Foundations of Faith API'});
    if(req.method==='POST' && path.endsWith('/auth/register')){
      const {email,password,role='parent',displayName}=req.body||{};
      if(!email||!password||!displayName) return send(res,400,{error:'email, password, and displayName are required.'});
      if(!['student','parent','teacher'].includes(role)) return send(res,400,{error:'Invalid registration role.'});
      if(String(password).length<10) return send(res,400,{error:'Password must be at least 10 characters.'});
      const exists=await pool.query('SELECT id FROM users WHERE lower(email)=lower($1)',[email]);
      if(exists.rowCount) return send(res,409,{error:'An account with that email already exists.'});
      const hash=await bcrypt.hash(password,12);
      const r=await pool.query('INSERT INTO users(email,password_hash,role,display_name) VALUES(lower($1),$2,$3,$4) RETURNING id,email,role,display_name,created_at',[email,hash,role,displayName]);
      return send(res,201,{user:r.rows[0]});
    }
    if(req.method==='POST' && path.endsWith('/auth/login')){
      const {email,password}=req.body||{};
      if(!email||!password) return send(res,400,{error:'Email and password are required.'});
      const r=await pool.query('SELECT id,email,password_hash,role,display_name FROM users WHERE lower(email)=lower($1)',[email]);
      if(!r.rowCount) return send(res,401,{error:'Invalid email or password.'});
      const u=r.rows[0]; if(!(await bcrypt.compare(password,u.password_hash))) return send(res,401,{error:'Invalid email or password.'});
      const token=jwt.sign({id:u.id,email:u.email,role:u.role,displayName:u.display_name},process.env.JWT_SECRET,{expiresIn:'8h'});
      return send(res,200,{token,user:{id:u.id,email:u.email,role:u.role,displayName:u.display_name}});
    }
    if(req.method==='GET' && path.endsWith('/auth/me')){
      const u=requireUser(req,res); if(!u)return;
      const r=await pool.query('SELECT id,email,role,display_name,created_at FROM users WHERE id=$1',[u.id]);
      if(!r.rowCount)return send(res,404,{error:'User not found.'});
      return send(res,200,{user:r.rows[0]});
    }
    return send(res,404,{error:'Route not found.'});
  } catch(e) { console.error(e); return send(res,500,{error:'Server error.'}); }
};
