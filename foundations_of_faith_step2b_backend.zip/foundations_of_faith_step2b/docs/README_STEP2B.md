# Step 2B — Backend/Login Foundation

This package combines the current public homepage with a Vercel serverless API and Neon PostgreSQL schema.

## Before deployment
1. In Neon/Vercel, run `database/schema.sql` against the database.
2. Keep `DATABASE_URL` and `JWT_SECRET` private.
3. Confirm Vercel environment variables include DATABASE_URL, JWT_SECRET, and FRONTEND_ORIGIN.

## API tests after deployment
- GET `/api/health`
- POST `/api/auth/register`
- POST `/api/auth/login`
- GET `/api/auth/me` with a Bearer token

This is the authentication foundation, not the complete school platform. Enrollment, courses, lessons, assignments, quizzes, grades, submissions, progress, email verification, password reset, rate limiting, audit logging, and final security/legal review still need to be added before real student records are used.
